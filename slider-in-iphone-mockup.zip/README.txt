A Pen created at CodePen.io. You can find this one at https://codepen.io/loublu94/pen/vRXxxm.

 This is demo of simple owl carousel slider inside iphone. 